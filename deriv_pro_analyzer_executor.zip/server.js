import express from "express";
import session from "express-session";
import crypto from "crypto";
import path from "path";
import {fileURLToPath} from "url";
const __dirname=path.dirname(fileURLToPath(import.meta.url)),app=express();
app.use(express.json());
app.use(session({secret:process.env.SESSION_SECRET||crypto.randomBytes(32).toString("hex"),resave:false,saveUninitialized:false,cookie:{httpOnly:true,secure:true,sameSite:"lax"}}));
app.use(express.static(path.join(__dirname,"public")));
const clientId=process.env.DERIV_CLIENT_ID,redirectUri=process.env.DERIV_REDIRECT_URI;
const b64=b=>b.toString("base64").replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
app.get("/auth/deriv",(req,res)=>{
 if(!clientId||!redirectUri)return res.status(500).send("Configure OAuth environment variables.");
 const verifier=b64(crypto.randomBytes(48)),challenge=b64(crypto.createHash("sha256").update(verifier).digest()),state=b64(crypto.randomBytes(24));
 req.session.oauth={verifier,state};
 const u=new URL("https://auth.deriv.com/oauth2/auth");
 for(const [k,v] of Object.entries({response_type:"code",client_id:clientId,redirect_uri:redirectUri,scope:"trade",state,code_challenge:challenge,code_challenge_method:"S256"}))u.searchParams.set(k,v);
 res.redirect(u);
});
app.get("/oauth/callback",async(req,res)=>{
 try{
  const o=req.session.oauth;if(!o||req.query.state!==o.state||!req.query.code)return res.status(400).send("OAuth verification failed.");
  const body=new URLSearchParams({grant_type:"authorization_code",client_id:clientId,code:req.query.code,code_verifier:o.verifier,redirect_uri:redirectUri});
  const r=await fetch("https://auth.deriv.com/oauth2/token",{method:"POST",headers:{"content-type":"application/x-www-form-urlencoded"},body});
  const j=await r.json();if(!r.ok)return res.status(400).json(j);
  req.session.deriv={access_token:j.access_token};delete req.session.oauth;res.redirect("/");
 }catch(e){res.status(500).send("OAuth callback failed.");}
});
app.get("/api/session",(req,res)=>res.json({authenticated:!!req.session.deriv,realTradingEnabled:false}));
app.post("/api/trade",(req,res)=>res.status(403).json({error:"REAL_EXECUTION_LOCKED"}));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log("Running"));
