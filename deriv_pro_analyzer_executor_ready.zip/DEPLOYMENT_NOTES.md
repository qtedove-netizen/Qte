# Deployment-ready project

This package is prepared for deployment as a Node.js web application.

Start command:
npm start

Important:
- Keep real trading disabled while testing.
- Configure required environment variables on the hosting provider; do not put secrets in public files.
- Never upload a Deriv API token, password, or other secret to GitHub.
