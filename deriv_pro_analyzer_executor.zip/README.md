# Deriv Pro Analyzer + Executor
Mobile-first web-app starter. OAuth2/PKCE login, public live analysis, and a server-side execution safety gate.
Real execution is NOT enabled in this package until a registered Deriv OAuth app, authorized account selection, server-side OTP flow, risk policy, and authenticated buy service are configured.
